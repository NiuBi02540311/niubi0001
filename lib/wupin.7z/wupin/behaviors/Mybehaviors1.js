module.exports = Behavior({

  data:{
    userName:'zhangsan'
  },
  properties:{

  },
  methods:{
    
  }
})