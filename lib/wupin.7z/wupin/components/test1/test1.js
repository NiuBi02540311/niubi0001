// components/test1/test1.js
Component({

  /**
   * 组件的属性列表
   */
  properties: {
    max:{
      type:Number,value:10
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    count:0, a:0,  b:0,
  },

  /**
   * 组件的方法列表
   */
  methods: {
    adda(){
      this.setData({
        a: this.data.a+1,
      })
    },
    addb(){
      this.setData({
        b: this.data.b+1,
      })
    },
    addcount(){
      if(this.data.count == this.properties.max) return
      this.setData({
        count: this.data.count+1,
        max: this.properties.max+1
      })
      this._showcount()
    },
    _showcount(){
      wx.showToast({
        title: 'count =' + this.data.count,
      })
    }
  },
  observers:{
    'a,b':function(aa,bb){
      this.setData({
        sum: aa + bb 
      })
    }
  }
})