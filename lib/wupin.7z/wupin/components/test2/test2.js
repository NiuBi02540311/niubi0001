// components/test2/test2.js
 const Mybehaviors1 = require('../../behaviors/Mybehaviors1')
Component({
  behaviors:[Mybehaviors1],
  /**
   * 组件的属性列表
   */
  properties: {

  },
  lifetimes:{
    created(){
      console.log('created')
      console.log(this.behaviors)
    },
    attached(){
      console.log('attached')
    }
  },
  pageLifetimes:{
    show(){
      console.log("页面显示了")
      this.RandColor()
    },
    hide(){
      console.log("页面隐藏了")
    },
    resize(){
      console.log("页面尺寸变化了")
    }
  },
  /**
   * 组件的初始数据
   */
  data: {
    rgb:{r:0,g:0,b:0},
    fullcolor:'0,0,0',
    count:0
  },

  /**
   * 组件的方法列表
   */
  methods: {
    changeR(){
      this.setData({
        'rgb.r' : this.data.rgb.r +10
      })
      this.triggerEvent('st',{value:this.data.fullcolor})
    },
    changeG(){
      this.setData({
        'rgb.g' : this.data.rgb.g +10
      })
    },
    changeB(){
      this.setData({
        'rgb.b' : this.data.rgb.b +10
      })
    },
    RandColor(){
      this.setData({
        'rgb.r' : Math.floor(Math.random()*256),
        'rgb.g' : Math.floor(Math.random()*256),
        'rgb.b' : Math.floor(Math.random()*256)
      })
    },
    syscount(e){
      console.log(e)
    }
  },
  observers:{
    // 'rgb.r,rgb.g,rgb.b':function(r,g,b){
    //  this.setData({
    //   fullcolor: r + ","+ g + "," + b
    //  })
    // }
    'rgb.**':function(obj){
      this.setData({
       fullcolor: obj.r + ","+ obj.g + "," + obj.b
      })
     }
  }
})