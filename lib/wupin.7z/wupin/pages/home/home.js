// pages/home/home.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    swiperList: [],
    gridList:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
   console.log(123)
   this.GetswiperList()
  },
  GetswiperList(){
   /*
    wx.request({
      url: 'https://www.escook.cn/slides',
      method:'GET',
      success:(res) =>{
        console.log(res)
      }
    })
   */
  this.setData(
  {    
    swiperList : [
    {id:1,src:"/images/tabs/home1.png"},
     {id:2,src:"/images/tabs/message1.png"}, 
     {id:3,src:"/images/tabs/contact1.png"} 
    ],
    gridList:[
      {id:1,name:"name1",src:"/images/tabs/home1.png"},
      {id:2,name:"name2",src:"/images/tabs/home1.png"},
      {id:3,name:"name3",src:"/images/tabs/home1.png"},
      {id:4,name:"name4",src:"/images/tabs/home1.png"},
      {id:5,name:"name5",src:"/images/tabs/home1.png"},
      {id:6,name:"name6",src:"/images/tabs/home1.png"},
      {id:7,name:"name7",src:"/images/tabs/home1.png"},
      {id:8,name:"name8",src:"/images/tabs/home1.png"},
      {id:9,name:"name9",src:"/images/tabs/home1.png"}

    ]
  }
  )
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },
  btnfn(e){
    console.log()
    const name = e.target.dataset.name
    wx.navigateTo({
      url: '/pages/shoplist/shoplist?name='+name,
    })

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})