// pages/info/info.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
  btnfn(){
    wx.switchTab({
      url: '/pages/home/home',
    })

  },
  syscount(e){
    //console.log(e)
    console.log(e.detail.value)
  },
  btnfn2(){
   const t2 = this.selectComponent(".sc")
   // 或  const t3 = this.selectComponent("#sd")
    t2.setData({count: t2.data.count + 100 })
    t2.setData({
      'rgb.r' : t2.data.rgb.r + 15,
      'rgb.g' : t2.data.rgb.g + 15,
      'rgb.b' : t2.data.rgb.b + 15,
    })
    t2.changeR()
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})