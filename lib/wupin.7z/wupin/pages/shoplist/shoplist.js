// pages/shoplist/shoplist.js
var utils=require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    query: {},
    datalist:[],
    pageIndex:1,
    pageSize:50,
    total:500,
    isLoading: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    //console.log(utils.rootDocment)
    //utils.showModal('title', 'content')
    console.log(options)
    this.setData({
        query : options

    })
    this. getShoplist()

  },
  testGetMethod(){
    wx.request({
      url: utils.rootDocment + '/Test/demo5',
      method:'GET',
      header:{
        access_token:"xx00"
      },
      data:{
        name:"weixin"
      },
      success(res){
        console.log(res.data)
      },
      fail(err){
        console.log(err)
      }
    })
  },
  getShoplist(){
    this.setData({ isLoading : true })
    wx.showLoading({
      title: '数据加载中',
    })
     let arr = []
     let begin = this.data.pageIndex > 1 ? (this.data.pageIndex - 1) *  this.data.pageSize + 1 :1
     let end = this.data.pageIndex * this.data.pageSize
     if(end > this.data.total){
       //console.log("已经全部显示")
       wx.hideLoading()
       wx.showToast({
         title: '数据已全部显示了',
       })
       return
     }
    for(let i = begin;i <= end;i++){
      arr.push(i)
      //console.log(i)
    }
    //console.log(arr)
    console.log(begin)
    console.log(end)
    this.setData({
      pageIndex : this.data.pageIndex + 1,
      datalist : [...this.data.datalist,...arr],
      isLoading : false
    })

    console.log(this.data.datalist)
    wx.hideLoading()
  },
  btnfn(){
    wx.switchTab({
      url: '/pages/home/home',
    })

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    wx.setNavigationBarTitle({
      title: this.data.query.name,
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
    if(this.data.isLoading) return;
    this.getShoplist()
    console.log("onReachBottom")
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})